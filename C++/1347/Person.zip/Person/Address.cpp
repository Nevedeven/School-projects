#include "Address.h"


Address::Address(void)
{
}


Address::~Address(void)
{
}
