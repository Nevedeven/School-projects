#include "Person.h"


Person::Person(void)
{
}


Person::~Person(void)
{
}
