#pragma once
class Person
{
public:
	Person(void);
	~Person(void);
};

