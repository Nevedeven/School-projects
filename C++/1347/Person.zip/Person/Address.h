#pragma once
class Address
{
public:
	Address(void);
	~Address(void);
};

